/**
* ************** How to use this firmware - READ THIS, yes actually read this. *********************************
*
* This is for beta machine testing only. Enable the beta machine below and set the other options in Configuration.h
*
*/

#ifndef CONFIGURATION_BETA_H
#define CONFIGURATION_BETA_H
#define CONFIGURATION_BETA_H_VERSION 010109


//===========================================================================
// ***********************   COPYMASTER PRINTERS    *************************
//===========================================================================

//===========================================================================
// Copymaster 3D 300 Options - Select 'Arduino Mega 2560' from Tools > Board
//===========================================================================
//#define COPYMASTER3D_300

// EZABL Probe Mounts
//#define CUSTOM_PROBE


//GEEETECH_A10M GEEETECH_A20M GEEETECH_A20

#endif // CONFIGURATION_H
