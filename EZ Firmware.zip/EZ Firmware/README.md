**This firmware is maintained by TH3D. The goal is an easy to use firmware for 3D printers that we have added support for.**

**The issues queue has been disabled as some people do not understand it's for firmware problems and not technical support.**

----------

Works with printers that are stock as well as ones using our products we sell like the [EZABL](https://www.th3dstudio.com/ezabl-kit/) and [EZOut](https://www.th3dstudio.com/product/ezout-cr-10-filament-sensor-kit/).

This is meant to be used with the TH3D line of products or stock machines. This may not work with other products so use at your own risk.

Please download from http://firmware.th3dstudio.com. Additional programs are needed to flash the firmware and are contained in the download on our website.

----------

- EZABL Auto Bed Leveling Kits: [https://www.th3dstudio.com/product-category/auto-bed-leveling/](https://www.th3dstudio.com/product-category/auto-bed-leveling/)
- EZOut: [https://www.th3dstudio.com/product/ezout-cr-10-filament-sensor-kit/](https://www.th3dstudio.com/product/ezout-cr-10-filament-sensor-kit/)
- All Products:[ https://www.th3dstudio.com/shop/](https://www.th3dstudio.com/shop/)


----------


**THIS IS PROVIDED UNDER THE GPL V3 LICENSE.
PROVIDED AS-IS. NO SUPPORT OR WARRANTY IS PROVIDED.**

Based on [Marlin](http://marlinfw.org) 1.1.9 Stable. Highly customized and modified for easy use with stock printer boards. If you have a custom machine it is best to use vanilla [Marlin](http://marlinfw.org).
